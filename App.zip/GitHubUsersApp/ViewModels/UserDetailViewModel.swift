import Foundation

@Observable class UserDetailViewModel {
    let username: String
    @Published var userDetail: GitHubUserDetail?
    @Published var isFollowed: Bool = false

    init(username: String) {
        self.username = username
        loadFollowState()
    }

    func fetchDetails() async {
        let url = URL(string: "https://api.github.com/users/\(username)")!
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            userDetail = try JSONDecoder().decode(GitHubUserDetail.self, from: data)
        } catch {
            print("Error fetching detail: \(error)")
        }
    }

    func toggleFollow() {
        isFollowed.toggle()
        UserDefaults.standard.set(isFollowed, forKey: "followed_\(username)")
    }

    private func loadFollowState() {
        isFollowed = UserDefaults.standard.bool(forKey: "followed_\(username)")
    }
}