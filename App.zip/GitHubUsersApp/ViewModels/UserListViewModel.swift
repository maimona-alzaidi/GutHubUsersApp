import Foundation

class UserListViewModel: ObservableObject {
    @Published var users: [GitHubUser] = []

    func fetchUsers() async {
        let url = URL(string: "https://api.github.com/users")!
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            users = try JSONDecoder().decode([GitHubUser].self, from: data)
        } catch {
            print("Error fetching users: \(error)")
        }
    }
}