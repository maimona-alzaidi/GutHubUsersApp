struct GitHubUserDetail: Identifiable, Codable {
    let id: Int
    let login: String
    let name: String?
    let avatar_url: String
    let bio: String?
    let location: String?
    let followers: Int
    let following: Int
}