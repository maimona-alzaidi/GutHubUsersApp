import SwiftUI
import SwiftData

@main
struct GitHubUsersApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                UserListView()
            }
        }
    }
}