import SwiftUI

struct UserDetailView: View {
    @StateObject private var viewModel: UserDetailViewModel

    init(username: String) {
        _viewModel = StateObject(wrappedValue: UserDetailViewModel(username: username))
    }

    var body: some View {
        VStack {
            if let detail = viewModel.userDetail {
                AsyncImage(url: URL(string: detail.avatar_url)) { image in
                    image.resizable()
                } placeholder: {
                    ProgressView()
                }
                .frame(width: 100, height: 100)
                .clipShape(Circle())
                .padding()

                Text(detail.name ?? detail.login)
                    .font(.title)
                    .bold()

                Text("@\(detail.login)")
                    .foregroundColor(.gray)

                VStack(alignment: .leading, spacing: 10) {
                    if let bio = detail.bio {
                        Text("Bio: \(bio)")
                    }
                    if let location = detail.location {
                        Text("Location: \(location)")
                    }
                    Text("Followers: \(detail.followers)")
                    Text("Following: \(detail.following)")
                }
                .padding()
            } else {
                ProgressView().onAppear {
                    Task { await viewModel.fetchDetails() }
                }
            }
        }
        .toolbar {
            Button(viewModel.isFollowed ? "Unfollow" : "Follow") {
                viewModel.toggleFollow()
            }
        }
        .navigationTitle("Profile")
        .navigationBarTitleDisplayMode(.inline)
    }
}