import SwiftUI

struct UserListView: View {
    @StateObject private var viewModel = UserListViewModel()

    var body: some View {
        List(viewModel.users) { user in
            NavigationLink(destination: UserDetailView(username: user.login)) {
                HStack {
                    AsyncImage(url: URL(string: user.avatar_url)) { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }
                    .frame(width: 50, height: 50)
                    .clipShape(Circle())

                    Text(user.login).font(.headline)
                }
            }
        }
        .task {
            await viewModel.fetchUsers()
        }
        .navigationTitle("GitHub Users")
    }
}